"""Cynbit AI Project Scoper - core logic.

Pipeline:  brief -> requirement extraction -> effort model (P20/P50/P80)
           -> risks + clarifying questions -> proposal draft

Runs fully offline (rules + scikit-learn). If ANTHROPIC_API_KEY is set,
an LLM upgrades extraction and proposal writing; the ML estimator stays the same.
"""
from __future__ import annotations
import json, os, re
from functools import lru_cache
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.ensemble import GradientBoostingRegressor

SERVICES = {
    "web_dev":    ["website", "web app", "landing page", "portal", "web application", "wordpress", "react", "laravel"],
    "mobile_app": ["mobile app", "android", "ios", "flutter", "react native", "app store", "play store", "app for"],
    "ui_ux":      ["ui/ux", "ux", "redesign", "wireframe", "figma", "prototype", "design system"],
    "seo":        ["seo", "search engine", "ranking", "keywords", "backlink", "organic traffic"],
    "custom_sw":  ["crm", "erp", "custom software", "automation", "workflow", "saas", "internal tool"],
    "ecommerce":  ["ecommerce", "e-commerce", "online store", "shopify", "woocommerce", "cart", "checkout"],
}

# feature -> (keywords, base hours used by the synthetic data generator)
FEATURES = {
    "auth":            (["login", "sign up", "signup", "authentication", "user accounts", "roles"], 30),
    "payments":        (["payment", "razorpay", "stripe", "paypal", "upi", "checkout"], 45),
    "admin_panel":     (["admin panel", "admin dashboard", "back office", "cms", "manage content", "manage products"], 50),
    "api_integration": (["api", "integration", "third-party", "webhook"], 40),
    "notifications":   (["notification", "push", "email alert", "sms", "whatsapp", "order alerts"], 25),
    "search":          (["site search", "search bar", "product search", "filter", "catalog"], 25),
    "booking":         (["booking", "appointment", "reservation", "scheduling"], 45),
    "chat":            (["chat", "live chat", "messaging"], 40),
    "analytics":       (["analytics", "reports", "reporting", "insights", "charts"], 35),
    "multilang":       (["multi-language", "multilingual", "hindi", "localization"], 25),
    "maps":            (["map", "gps", "location tracking", "geolocation"], 30),
    "ai_feature":      (["chatbot", "recommendation", "machine learning", "predict", " ai "], 70),
}
FEATURE_NAMES = list(FEATURES)
SERVICE_NAMES = list(SERVICES)
HOURLY_RATE_USD = 18  # editable assumption: blended agency rate


# ----------------------------------------------------------------- extraction
def extract_rules(brief: str) -> dict:
    t = f" {brief.lower()} "
    services = [s for s, kws in SERVICES.items() if any(k in t for k in kws)] or ["web_dev"]
    feats = [f for f, (kws, _) in FEATURES.items() if any(k in t for k in kws)]
    m = re.search(r"(\d+)\s*\+?\s*(?:pages|screens)", t)
    pages = int(m.group(1)) if m else (8 if "web_dev" in services else 12)
    w = re.search(r"(\d+)\s*(week|month)", t)
    weeks = int(w.group(1)) * (4 if w.group(2) == "month" else 1) if w else None
    platforms = 2 if ("android" in t and "ios" in t) or "cross-platform" in t or "flutter" in t else 1
    return {"services": services, "features": feats, "pages": pages,
            "deadline_weeks": weeks, "platforms": platforms, "source": "rules"}


def extract_llm(brief: str) -> dict | None:
    """Optional: structured extraction via Claude. Returns None on any failure."""
    if not os.getenv("ANTHROPIC_API_KEY"):
        return None
    try:
        import anthropic
        client = anthropic.Anthropic()
        system = ("You extract software project requirements. Reply with JSON only: "
                  f'{{"services": subset of {SERVICE_NAMES}, "features": subset of {FEATURE_NAMES}, '
                  '"pages": int, "deadline_weeks": int|null, "platforms": 1|2}. '
                  "Only include items clearly implied by the brief.")
        r = client.messages.create(model=os.getenv("CLAUDE_MODEL", "claude-sonnet-4-6"),
                                   max_tokens=500, system=system,
                                   messages=[{"role": "user", "content": brief}])
        data = json.loads(re.sub(r"```json|```", "", r.content[0].text).strip())
        data["services"] = [s for s in data.get("services", []) if s in SERVICES] or ["web_dev"]
        data["features"] = [f for f in data.get("features", []) if f in FEATURES]
        data["pages"] = int(data.get("pages") or 8)
        data["platforms"] = int(data.get("platforms") or 1)
        data.setdefault("deadline_weeks", None)
        data["source"] = "llm"
        return data
    except Exception:
        return None


# ---------------------------------------------------------------- effort model
def to_row(req: dict) -> dict:
    row = {f"svc_{s}": int(s in req["services"]) for s in SERVICE_NAMES}
    row.update({f"feat_{f}": int(f in req["features"]) for f in FEATURE_NAMES})
    row.update({"pages": req["pages"], "platforms": req["platforms"],
                "deadline_weeks": req["deadline_weeks"] or 12})
    return row


def synthetic_history(n: int = 600, seed: int = 7) -> pd.DataFrame:
    """Stand-in for Cynbit's past projects. REPLACE with real data (see docs)."""
    rng = np.random.default_rng(seed)
    base = {"web_dev": 80, "mobile_app": 220, "ui_ux": 60, "seo": 70, "custom_sw": 260, "ecommerce": 180}
    rows = []
    for _ in range(n):
        svcs = list(rng.choice(SERVICE_NAMES, size=rng.integers(1, 3), replace=False))
        feats = list(rng.choice(FEATURE_NAMES, size=rng.integers(0, 6), replace=False))
        req = {"services": svcs, "features": feats, "pages": int(rng.integers(3, 40)),
               "platforms": int(rng.choice([1, 2], p=[.7, .3])),
               "deadline_weeks": int(rng.integers(3, 30))}
        hrs = sum(base[s] for s in svcs) + sum(FEATURES[f][1] for f in feats) + req["pages"] * 4
        hrs *= 1 + 0.35 * (req["platforms"] - 1)
        hrs *= 1.15 if req["deadline_weeks"] < 6 else 1.0   # rush overhead
        hrs *= rng.lognormal(0, 0.18)                        # real-world noise
        rows.append({**to_row(req), "hours": hrs})
    return pd.DataFrame(rows)


@lru_cache(maxsize=1)
def train_model(csv_path: str | None = None):
    """Three quantile GBMs -> optimistic / likely / pessimistic hours."""
    df = pd.read_csv(csv_path) if csv_path and Path(csv_path).exists() else synthetic_history()
    X, y = df.drop(columns="hours"), np.log(df["hours"])
    models = {q: GradientBoostingRegressor(loss="quantile", alpha=q, n_estimators=200,
                                           max_depth=3, learning_rate=0.05, random_state=0).fit(X, y)
              for q in (0.2, 0.5, 0.8)}
    return models, list(X.columns)


def estimate(req: dict, csv_path: str | None = None) -> dict:
    models, cols = train_model(csv_path)
    X = pd.DataFrame([to_row(req)])[cols]
    p20, p50, p80 = sorted(float(np.exp(models[q].predict(X)[0])) for q in (0.2, 0.5, 0.8))
    return {"hours_low": round(p20), "hours_likely": round(p50), "hours_high": round(p80),
            "cost_low": round(p20 * HOURLY_RATE_USD, -1), "cost_high": round(p80 * HOURLY_RATE_USD, -1),
            "weeks_likely": max(2, round(p50 / (4 * 35)))}  # ~4 devs x 35 productive hrs/week


# ----------------------------------------------------- risks, questions, proposal
def risks_and_questions(brief: str, req: dict) -> tuple[list[str], list[str]]:
    t, risks, qs = brief.lower(), [], []
    if not req["deadline_weeks"]:
        qs.append("What is the target launch date or hard deadline?")
    if not re.search(r"budget|\$|₹|inr|usd|lakh", t):
        qs.append("Is there a budget range we should design the scope around?")
    if "mobile_app" in req["services"] and req["platforms"] == 1 and "android" not in t and "ios" not in t:
        qs.append("Should the app target Android, iOS, or both (cross-platform)?")
    if "payments" in req["features"]:
        qs.append("Which payment gateway and which currencies/regions are required?")
    if "api_integration" in req["features"]:
        qs.append("Which third-party systems must we integrate, and are their API docs available?")
    if not re.search(r"existing|current|already", t):
        qs.append("Is this a new build or a rebuild of an existing product (and what stack)?")
    if req["deadline_weeks"] and req["deadline_weeks"] < 6:
        risks.append("Aggressive timeline: expect rush overhead or reduced MVP scope.")
    if "ai_feature" in req["features"]:
        risks.append("AI features need data access, evaluation criteria and ongoing tuning budget.")
    if len(req["features"]) >= 5:
        risks.append("High feature count: recommend phased delivery (MVP -> v2).")
    if re.search(r"\b(simple|just|quick|small)\b", t) and len(req["features"]) >= 3:
        risks.append("Client says 'simple' but scope is non-trivial: expectation gap.")
    if "payments" in req["features"] or "auth" in req["features"]:
        risks.append("Security/compliance review needed (auth, PII, payment data).")
    return risks or ["No major risks detected from the brief."], qs


def proposal_draft(req: dict, est: dict, risks: list[str], qs: list[str], use_llm: bool = True) -> str:
    feats = ", ".join(req["features"]) or "core pages and content"
    svcs = ", ".join(s.replace("_", " ") for s in req["services"])
    draft = (f"## Project Proposal (Draft)\n\n**Services:** {svcs}\n\n**Scope:** {feats}; "
             f"~{req['pages']} pages/screens; {req['platforms']} platform(s).\n\n"
             f"**Estimate:** {est['hours_low']}-{est['hours_high']} hours "
             f"(likely {est['hours_likely']}), approx. ${est['cost_low']:,.0f}-${est['cost_high']:,.0f}, "
             f"~{est['weeks_likely']} weeks.\n\n**Key risks:**\n" + "\n".join(f"- {r}" for r in risks) +
             "\n\n**Open questions:**\n" + "\n".join(f"- {q}" for q in qs) + "\n")
    if use_llm and os.getenv("ANTHROPIC_API_KEY"):
        try:
            import anthropic
            r = anthropic.Anthropic().messages.create(
                model=os.getenv("CLAUDE_MODEL", "claude-sonnet-4-6"), max_tokens=900,
                system=("You are a pre-sales consultant at Cynbit Technologies. Rewrite this draft into a "
                        "polished, client-ready proposal. Do NOT change any numbers or invent scope."),
                messages=[{"role": "user", "content": draft}])
            return r.content[0].text
        except Exception:
            pass
    return draft


def analyze_brief(brief: str, use_llm: bool = True) -> dict:
    req = (extract_llm(brief) if use_llm else None) or extract_rules(brief)
    est = estimate(req)
    risks, qs = risks_and_questions(brief, req)
    return {"requirements": req, "estimate": est, "risks": risks, "questions": qs,
            "proposal": proposal_draft(req, est, risks, qs, use_llm)}

import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
from scoper import analyze_brief

def test_ecommerce():
    r = analyze_brief("Online store with Razorpay checkout, user accounts, admin panel. 15 pages in 2 months.", use_llm=False)
    assert "ecommerce" in r["requirements"]["services"]
    assert {"payments", "auth", "admin_panel"} <= set(r["requirements"]["features"])
    e = r["estimate"]
    assert e["hours_low"] <= e["hours_likely"] <= e["hours_high"]

def test_more_scope_costs_more():
    a = analyze_brief("simple website, 5 pages", use_llm=False)["estimate"]["hours_likely"]
    b = analyze_brief("mobile app android and ios with payments, chat, maps, admin panel, ai chatbot", use_llm=False)["estimate"]["hours_likely"]
    assert b > a

if __name__ == "__main__":
    test_ecommerce(); test_more_scope_costs_more(); print("tests passed")
